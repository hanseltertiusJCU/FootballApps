package com.example.footballapps.lifecycle

interface FragmentLifecycle {
    fun onPauseFragment()
    fun onResumeFragment()
}