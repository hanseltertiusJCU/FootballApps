package com.example.footballapps.model

data class LeagueItem(val leagueId: String?, val leagueName: String?, val leagueImage: Int?)